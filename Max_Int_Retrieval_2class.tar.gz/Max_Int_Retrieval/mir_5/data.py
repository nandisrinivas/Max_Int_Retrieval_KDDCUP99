import os
import sys
import pdb
import torch
import numpy as np
import pickle as pkl
from PIL import Image
from random import shuffle
import cv2
import numpy as np
import tensorflow as tf
import glob
import pandas as pd

from torchvision import datasets, transforms
from sklearn import preprocessing

class kddcup99_train:
    """
    Class for the kddcup99 intrusion detection dataset.
    """
     

    def converter(self, s):
        if (s == 'icmp'): return 0.0
        elif (s == 'tcp'): return 1.0
        elif (s == 'udp'): return 2.0
        elif (s == 'IRC'): return 0.0
        elif (s == 'X11'): return 1.0
        elif (s == 'Z39_50'): return 2.0
        elif (s == 'aol'): return 3.0
        elif (s == 'atuh'): return 4.0
        elif (s == 'bgp'): return 5.0
        elif (s == 'courier'): return 6.0
        elif (s == 'csnet_ns'): return 7.0
        elif (s == 'ctf'): return 8.0
        elif (s == 'daytime'): return 9.0
        elif (s == 'discard'): return 10.0
        elif (s == 'domain'): return 11.0
        elif (s == 'domain_u'): return 12.0
        elif (s == 'echo'): return 13.0
        elif (s == 'eco_i'): return 14.0
        elif (s == 'ecr_i'): return 15.0
        elif (s == 'efs'): return 16.0
        elif (s == 'exec'): return 17.0
        elif (s == 'finger'): return 18.0
        elif (s == 'ftp'): return 19.0
        elif (s == 'ftp_data'): return 20.0
        elif (s == 'gopher'): return 21.0
        elif (s == 'harvest'): return 22.0
        elif (s == 'hostname'): return 23.0
        elif (s == 'http'): return 24.0
        elif (s == 'http_278'): return 25.0
        elif (s == 'http_443'): return 26.0
        elif (s == 'http_800'): return 27.0
        elif (s == 'imap4'): return 28.0
        elif (s == 'iso_tsap'): return 29.0
        elif (s == 'klogin'): return 30.0
        elif (s == 'kshell'): return 31.0
        elif (s == 'ldap'): return 32.0
        elif (s == 'link'): return 33.0
        elif (s == 'login'): return 34.0
        elif (s == 'mtp'): return 35.0
        elif (s == 'name'): return 36.0
        elif (s == 'netbios_'): return 37.0
        elif (s == 'netstat'): return 38.0
        elif (s == 'nnsp'): return 39.0
        elif (s == 'nntp'): return 40.0
        elif (s == 'ntp_u'): return 41.0
        elif (s == 'other'): return 42.0
        elif (s == 'pm_dump'): return 43.0
        elif (s == 'pop_2'): return 44.0
        elif (s == 'pop_3'): return 45.0
        elif (s == 'printer'): return 46.0
        elif (s == 'private'): return 47.0
        elif (s == 'red_i'): return 48.0
        elif (s == 'remote_j'): return 49.0
        elif (s == 'rje'): return 50.0
        elif (s == 'shell'): return 51.0
        elif (s == 'smtp'): return 52.0
        elif (s == 'sql_net'): return 53.0
        elif (s == 'ssh'): return 54.0
        elif (s == 'sunrpc'): return 55.0
        elif (s == 'supdup'): return 56.0
        elif (s == 'systat'): return 57.0
        elif (s == 'telnet'): return 58.0
        elif (s == 'tftp_u'): return 59.0
        elif (s == 'tim_i'): return 60.0
        elif (s == 'time'): return 61.0
        elif (s == 'urh_i'): return 62.0
        elif (s == 'urp_i'): return 63.0
        elif (s == 'uucp'): return 64.0
        elif (s == 'uucp_pat'): return 65.0
        elif (s == 'vmnet'): return 66.0
        elif (s == 'whois'): return 67.0
        elif (s == 'OTH'): return 0.0
        elif (s == 'REJ'): return 1.0
        elif (s == 'RSTO'): return 2.0
        elif (s == 'RSTR'): return 3.0
        elif (s == 'S0'): return 4.0
        elif (s == 'S1'): return 5.0
        elif (s == 'S2'): return 6.0
        elif (s == 'S3'): return 7.0
        elif (s == 'SF'): return 8.0
        elif (s == 'Sh'): return 9.0
        elif (s == 'back'): return 0.0
        elif (s == 'buffer_overflow'): return 1.0
        elif (s == 'ftp_write'): return 2.0
        elif (s == 'guess_passwd'): return 3.0
        elif (s == 'imap'): return 4.0
        elif (s == 'ipsweep'): return 5.0
        elif (s == 'land'): return 6.0
        elif (s == 'loadmodule'): return 7.0
        elif (s == 'multihop'): return 8.0
        elif (s == 'neptune'): return 9.0
        elif (s == 'nmap'): return 10.0
        elif (s == 'normal'): return 11.0
        elif (s == 'perl'): return 12.0
        elif (s == 'phf'): return 13.0
        elif (s == 'pod'): return 14.0
        elif (s == 'portsweep'): return 15.0
        elif (s == 'rootkit'): return 16.0
        elif (s == 'satan'): return 17.0
        elif (s == 'smurf'): return 18.0
        elif (s == 'spy'): return 19.0
        elif (s == 'teardrop'): return 20.0
        elif (s == 'warezclient'): return 21.0
        elif (s == 'warezmaster'): return 22.0
        else: return -1.0

    def __init__(self):
        # Load kddcup99 data
        self.data_list =[ ]
        self.label_list =[ ]
        col_names = ["duration", "protocol_type", "service", "flag", "src_bytes", "dst_bytes", "land", "wrong_fragment", "urgent", "hot", 
             "num_failed_logins", "logged_in", "lnum_compromised", "lroot_shell", "lsu_attempted", "lnum_root", "lnum_file_creations", 
             "lnum_shells", "lnum_access_files", "lnum_outbound_cmds", "is_host_login", "is_guest_login", "count", "srv_count", 
             "serror_rate", "srv_serror_rate", "rerror_rate", "srv_rerror_rate", "same_srv_rate", "diff_srv_rate", 
             "srv_diff_host_rate", "dst_host_count","dst_host_srv_count", "dst_host_same_srv_rate", "dst_host_diff_srv_rate", 
             "dst_host_same_src_port_rate", "dst_host_srv_diff_host_rate", "dst_host_serror_rate", "dst_host_srv_serror_rate", 
             "dst_host_rerror_rate", "dst_host_srv_rerror_rate", "label"]
        print("loading data")
        attack_int=0
        data = pd.read_csv("/home/srinivas/Desktop/kddcup.data_10_percent_corrected", delimiter=",", converters={1: self.converter, 2: self.converter, 3: self.converter},header=None, names = col_names)
        print(data.tail())
        print(list(data))
        data_without_label=data.iloc[:,0:41]
        print(list(data_without_label))
        print(data_without_label.tail())
        datadnp=data_without_label.to_numpy()
        print("--------------------------------------------data for features-------------------------------------------------------------")
        print(datadnp)
        print("---------------------------------------------end---------------------------------------------------------------------------")
        for i,lab in enumerate (data['label']):
            if lab=='normal.':
                np_array=np.asarray(datadnp[attack_int],dtype=float)
                self.data_list.append(np_array)
                self.label_list.append(0)
                attack_int+=1
            elif lab=='smurf.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='neptune.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='pod.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='teardrop.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='land.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='back.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='apache2.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='udpstorm.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='processtable.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='mailbomb.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='buffer_overflow.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='xterm.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='ps.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='httptunnel.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='sqlattack.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='worm.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='loadmodule.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='snmpguess.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='perl.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='rootkit.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='spy.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='guess_passwd.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='ftp_write.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='imap.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='phf.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='multihop.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='warezmaster.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='warezclient.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='sendmail.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='snmpgetattack.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='named.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='xlock.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='xsnoop.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='portsweep.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='ipsweep.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='nmap.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='satan.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='saint.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='mscan.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            else: attack_int+=1
        print(attack_int)
        self.data_list=torch.tensor(self.data_list)
        self.label_list = torch.from_numpy(np.array(self.label_list, dtype=int))
        print(self.data_list)
        print(self.data_list.shape)
        print(self.data_list.dtype)
        print(self.label_list)
        print(self.label_list.shape)
        print(self.label_list.dtype)
    def __list__(self):
        return list(self.data_list),list(self.label_list)

class kddcup99_test:
    """
    Class for the kddcup99 intrusion detection dataset.
    """
     

    def converter(self, s):
        if (s == 'icmp'): return 0.0
        elif (s == 'tcp'): return 1.0
        elif (s == 'udp'): return 2.0
        elif (s == 'IRC'): return 0.0
        elif (s == 'X11'): return 1.0
        elif (s == 'Z39_50'): return 2.0
        elif (s == 'aol'): return 3.0
        elif (s == 'atuh'): return 4.0
        elif (s == 'bgp'): return 5.0
        elif (s == 'courier'): return 6.0
        elif (s == 'csnet_ns'): return 7.0
        elif (s == 'ctf'): return 8.0
        elif (s == 'daytime'): return 9.0
        elif (s == 'discard'): return 10.0
        elif (s == 'domain'): return 11.0
        elif (s == 'domain_u'): return 12.0
        elif (s == 'echo'): return 13.0
        elif (s == 'eco_i'): return 14.0
        elif (s == 'ecr_i'): return 15.0
        elif (s == 'efs'): return 16.0
        elif (s == 'exec'): return 17.0
        elif (s == 'finger'): return 18.0
        elif (s == 'ftp'): return 19.0
        elif (s == 'ftp_data'): return 20.0
        elif (s == 'gopher'): return 21.0
        elif (s == 'harvest'): return 22.0
        elif (s == 'hostname'): return 23.0
        elif (s == 'http'): return 24.0
        elif (s == 'http_278'): return 25.0
        elif (s == 'http_443'): return 26.0
        elif (s == 'http_800'): return 27.0
        elif (s == 'imap4'): return 28.0
        elif (s == 'iso_tsap'): return 29.0
        elif (s == 'klogin'): return 30.0
        elif (s == 'kshell'): return 31.0
        elif (s == 'ldap'): return 32.0
        elif (s == 'link'): return 33.0
        elif (s == 'login'): return 34.0
        elif (s == 'mtp'): return 35.0
        elif (s == 'name'): return 36.0
        elif (s == 'netbios_'): return 37.0
        elif (s == 'netstat'): return 38.0
        elif (s == 'nnsp'): return 39.0
        elif (s == 'nntp'): return 40.0
        elif (s == 'ntp_u'): return 41.0
        elif (s == 'other'): return 42.0
        elif (s == 'pm_dump'): return 43.0
        elif (s == 'pop_2'): return 44.0
        elif (s == 'pop_3'): return 45.0
        elif (s == 'printer'): return 46.0
        elif (s == 'private'): return 47.0
        elif (s == 'red_i'): return 48.0
        elif (s == 'remote_j'): return 49.0
        elif (s == 'rje'): return 50.0
        elif (s == 'shell'): return 51.0
        elif (s == 'smtp'): return 52.0
        elif (s == 'sql_net'): return 53.0
        elif (s == 'ssh'): return 54.0
        elif (s == 'sunrpc'): return 55.0
        elif (s == 'supdup'): return 56.0
        elif (s == 'systat'): return 57.0
        elif (s == 'telnet'): return 58.0
        elif (s == 'tftp_u'): return 59.0
        elif (s == 'tim_i'): return 60.0
        elif (s == 'time'): return 61.0
        elif (s == 'urh_i'): return 62.0
        elif (s == 'urp_i'): return 63.0
        elif (s == 'uucp'): return 64.0
        elif (s == 'uucp_pat'): return 65.0
        elif (s == 'vmnet'): return 66.0
        elif (s == 'whois'): return 67.0
        elif (s == 'OTH'): return 0.0
        elif (s == 'REJ'): return 1.0
        elif (s == 'RSTO'): return 2.0
        elif (s == 'RSTR'): return 3.0
        elif (s == 'S0'): return 4.0
        elif (s == 'S1'): return 5.0
        elif (s == 'S2'): return 6.0
        elif (s == 'S3'): return 7.0
        elif (s == 'SF'): return 8.0
        elif (s == 'Sh'): return 9.0
        elif (s == 'back'): return 0.0
        elif (s == 'buffer_overflow'): return 1.0
        elif (s == 'ftp_write'): return 2.0
        elif (s == 'guess_passwd'): return 3.0
        elif (s == 'imap'): return 4.0
        elif (s == 'ipsweep'): return 5.0
        elif (s == 'land'): return 6.0
        elif (s == 'loadmodule'): return 7.0
        elif (s == 'multihop'): return 8.0
        elif (s == 'neptune'): return 9.0
        elif (s == 'nmap'): return 10.0
        elif (s == 'normal'): return 11.0
        elif (s == 'perl'): return 12.0
        elif (s == 'phf'): return 13.0
        elif (s == 'pod'): return 14.0
        elif (s == 'portsweep'): return 15.0
        elif (s == 'rootkit'): return 16.0
        elif (s == 'satan'): return 17.0
        elif (s == 'smurf'): return 18.0
        elif (s == 'spy'): return 19.0
        elif (s == 'teardrop'): return 20.0
        elif (s == 'warezclient'): return 21.0
        elif (s == 'warezmaster'): return 22.0
        else: return -1.0

    def __init__(self):
        # Load kddcup99 data
        self.data_list =[ ]
        self.label_list =[ ]
        col_names = ["duration", "protocol_type", "service", "flag", "src_bytes", "dst_bytes", "land", "wrong_fragment", "urgent", "hot", 
             "num_failed_logins", "logged_in", "lnum_compromised", "lroot_shell", "lsu_attempted", "lnum_root", "lnum_file_creations", 
             "lnum_shells", "lnum_access_files", "lnum_outbound_cmds", "is_host_login", "is_guest_login", "count", "srv_count", 
             "serror_rate", "srv_serror_rate", "rerror_rate", "srv_rerror_rate", "same_srv_rate", "diff_srv_rate", 
             "srv_diff_host_rate", "dst_host_count","dst_host_srv_count", "dst_host_same_srv_rate", "dst_host_diff_srv_rate", 
             "dst_host_same_src_port_rate", "dst_host_srv_diff_host_rate", "dst_host_serror_rate", "dst_host_srv_serror_rate", 
             "dst_host_rerror_rate", "dst_host_srv_rerror_rate", "label"]
        print("loading data")
        attack_int=0
        data = pd.read_csv("/home/srinivas/Desktop/corrected", delimiter=",", converters={1: self.converter, 2: self.converter, 3: self.converter},header=None, names = col_names)
        print(data.tail())
        print(list(data))
        data_without_label=data.iloc[:,0:41]
        print(list(data_without_label))
        print(data_without_label.tail())
        datadnp=data_without_label.to_numpy()
        print("--------------------------------------------data for features-------------------------------------------------------------")
        print(datadnp)
        print("---------------------------------------------end---------------------------------------------------------------------------")
        for i,lab in enumerate (data['label']):
            if lab=='normal.':
                np_array=np.asarray(datadnp[attack_int],dtype=float)
                self.data_list.append(np_array)
                self.label_list.append(0)
                attack_int+=1
            elif lab=='smurf.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='neptune.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='pod.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='teardrop.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='land.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='back.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='apache2.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='udpstorm.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='processtable.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='mailbomb.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='buffer_overflow.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='xterm.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='ps.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='httptunnel.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='sqlattack.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='worm.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='loadmodule.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='snmpguess.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='perl.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='rootkit.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='spy.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='guess_passwd.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='ftp_write.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='imap.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='phf.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='multihop.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='warezmaster.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='warezclient.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='sendmail.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='snmpgetattack.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='named.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='xlock.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='xsnoop.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='portsweep.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='ipsweep.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='nmap.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='satan.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='saint.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            elif lab=='mscan.':
                  np_array=np.asarray(datadnp[attack_int],dtype=float)
                  self.data_list.append(np_array)
                  self.label_list.append(1)
                  attack_int+=1
            else: attack_int+=1
        print(attack_int)
        self.data_list=torch.tensor(self.data_list)
        self.label_list = torch.from_numpy(np.array(self.label_list, dtype=int))
        print(self.data_list)
        print(self.data_list.shape)
        print(self.data_list.dtype)
        print(self.label_list)
        print(self.label_list.shape)
        print(self.label_list.dtype)
    def __list__(self):
        return list(self.data_list),list(self.label_list)




""" Template Dataset with Labels """
class XYDataset(torch.utils.data.Dataset):
    def __init__(self, x, y, **kwargs):
        self.x, self.y = x, y

        # this was to store the inverse permutation in permuted_mnist
        # so that we could 'unscramble' samples and plot them
        for name, value in kwargs.items():
            setattr(self, name, value)

    def __len__(self):
        return len(self.x)

    def __getitem__(self, idx):
        x, y = self.x[idx], self.y[idx]

        if type(x) != torch.Tensor:
            # mini_imagenet
            # we assume it's a path --> load from file
            x = self.transform(Image.open(x).convert('RGB'))
            y = torch.Tensor(1).fill_(y).long().squeeze()
        else:
            x = x.float() / 255.
            y = y.long()


        # for some reason mnist does better \in [0,1] than [-1, 1]
        if self.source == 'kddcup99':
            return x, y
        else:
            return (x - 0.5) * 2, y


""" Template Dataset for Continual Learning """
class CLDataLoader(object):
    def __init__(self, datasets_per_task, args, train=True):
        bs = args.batch_size if train else 64

        self.datasets = datasets_per_task
        self.loaders = [
                torch.utils.data.DataLoader(x, batch_size=bs, shuffle=True, drop_last=train, num_workers=0)
                for x in self.datasets ]

    def __getitem__(self, idx):
        return self.loaders[idx]

    def __len__(self):
        return len(self.loaders)

def get_kddcup99(args):
    args.multiple_heads = False
    args.n_classes = 2
    args.n_tasks = 2 if args.n_tasks==-1 else args.n_tasks
    if 'mem_size' in args:
        args.buffer_size = args.n_tasks * args.mem_size * 2
    args.use_conv = False
    args.input_type = 'binary'
    args.input_size = 41
    if args.output_loss is None:
        args.output_loss = 'bernouilli'

    assert args.n_tasks in [2, 5], 'kddcup99 only works with 5 or 10 tasks'
    assert '1.' in str(torch.__version__)[:2], 'Use Pytorch 1.x!'
    k=kddcup99_train()
    train_x=k.data_list
    train_y=k.label_list
    m=kddcup99_test()
    test_x=m.data_list
    test_y=m.label_list
    print("-----------------------train_x------------------------------------------train_y------------------------------------------")
    print(train_x)
    print(train_x.shape)
    print(train_y)
    out_train = [
        (x,y) for (x,y) in sorted(zip(train_x, train_y), key=lambda v : v[1]) ]

    out_test = [
        (x,y) for (x,y) in sorted(zip(test_x, test_y), key=lambda v : v[1]) ]

    train_x, train_y = [
            torch.stack([elem[i] for elem in out_train]) for i in [0,1] ]

    test_x,  test_y  = [
            torch.stack([elem[i] for elem in out_test]) for i in [0,1] ]


    # get indices of class split
    train_idx = [((train_y + i) % 2).argmax() for i in range(2)]
    train_idx = [0]+sorted(train_idx)
    print(train_idx)

    test_idx  = [((test_y + i) % 2).argmax() for i in range(2)]
    test_idx  = [0]+sorted(test_idx)

    train_ds, test_ds = [], []
    skip = 1
    for i in range(0, 2, skip):
        tr_s, tr_e = train_idx[i], train_idx[i + skip]
        te_s, te_e = test_idx[i],  test_idx[i + skip]

        train_ds += [(train_x[tr_s:tr_e], train_y[tr_s:tr_e])]
        test_ds  += [(test_x[te_s:te_e],  test_y[te_s:te_e])]

    train_ds, val_ds = make_valid_from_train(train_ds)

    train_ds = map(lambda x : XYDataset(x[0], x[1], **{'source': 'kddcup99'}), train_ds)
    val_ds   = map(lambda x : XYDataset(x[0], x[1], **{'source': 'kddcup99'}), val_ds)
    test_ds  = map(lambda x : XYDataset(x[0], x[1], **{'source': 'kddcup99'}), test_ds)


    return train_ds, val_ds, test_ds


def make_valid_from_train(dataset, cut=0.95):
    tr_ds, val_ds = [], []
    for task_ds in dataset:
        x_t, y_t = task_ds

        # shuffle before splitting
        perm = torch.randperm(len(x_t))
        x_t, y_t = x_t[perm], y_t[perm]

        split = int(len(x_t) * cut)
        x_tr, y_tr   = x_t[:split], y_t[:split]
        x_val, y_val = x_t[split:], y_t[split:]

        tr_ds  += [(x_tr, y_tr)]
        val_ds += [(x_val, y_val)]

    return tr_ds, val_ds
